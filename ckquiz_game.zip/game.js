
const quizData = [
    {
        question: "বাংলাদেশের রাজধানী কোথায়?",
        options: ["চট্টগ্রাম", "রাজশাহী", "ঢাকা", "খুলনা"],
        answer: "ঢাকা"
    },
    {
        question: "সৌরজগতের সবচেয়ে বড় গ্রহ কোনটি?",
        options: ["শনি", "বৃহস্পতি", "পৃথিবী", "মঙ্গল"],
        answer: "বৃহস্পতি"
    }
];

let current = 0;
const questionEl = document.getElementById("question");
const answersEl = document.getElementById("answers");

function loadQuiz() {
    const q = quizData[current];
    questionEl.textContent = q.question;
    answersEl.innerHTML = "";
    q.options.forEach(opt => {
        const btn = document.createElement("button");
        btn.textContent = opt;
        btn.onclick = () => {
            if (opt === q.answer) {
                alert("সঠিক উত্তর!");
            } else {
                alert("ভুল উত্তর!");
            }
            current = (current + 1) % quizData.length;
            loadQuiz();
        };
        answersEl.appendChild(btn);
    });
}

loadQuiz();
